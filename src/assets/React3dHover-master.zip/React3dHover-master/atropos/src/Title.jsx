function Title() {
  return (
    <>
      <h3>3D Hover Animation</h3>
    </>
  );
}

export default Title;
