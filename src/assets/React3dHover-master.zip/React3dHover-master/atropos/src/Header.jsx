function Header() {
  return (
    <>
      <div className="header">
        <ul>
          <li>Home</li>
          <li>About</li>
          <li>Service</li>
          <li>Contact</li>
        </ul>
      </div>
    </>
  );
}

export default Header;
